package com.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentmanagementsystemDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentmanagementsystemDemoApplication.class, args);
	}

}
