package com.sms.service;

import com.sms.entities.Student;

public interface StudentService {
	
	Student createStudent(Student student);
	

}
