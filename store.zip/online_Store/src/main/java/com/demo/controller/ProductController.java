package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entities.Product;
import com.demo.model.ProductDTO;
import com.demo.service.ProductService;
import com.demo.util.Converter;


@RestController
public class ProductController {
	@Autowired
	private Converter converter;
	@Autowired
	private ProductService productService;
	
	@PostMapping("/createProduct")
ResponseEntity<ProductDTO> createProduct(@RequestBody ProductDTO productDTO) 
{
   final Product product = converter.convertToProductEntity(productDTO);
   return new ResponseEntity<ProductDTO>(productService.createProduct(product),HttpStatus.CREATED);
}

}
