package com.demo.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.Product;
import com.demo.model.ProductDTO;
import com.demo.repositories.ProductRepository;
import com.demo.service.ProductService;
import com.demo.util.Converter;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
    private	ProductRepository productRepository;
	@Autowired
	private Converter converter;
	
	@Override
	public ProductDTO createProduct(Product product) {
		//Product p=productRepository.save(product);
		return converter.convertToProductDTO(productRepository.save(product));
	}

}
