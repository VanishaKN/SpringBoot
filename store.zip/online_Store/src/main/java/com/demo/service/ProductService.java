package com.demo.service;

import com.demo.entities.Product;
import com.demo.model.ProductDTO;

public interface ProductService {
	ProductDTO createProduct(Product product);

}
