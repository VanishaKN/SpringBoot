package com.demo.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.demo.entities.Product;
import com.demo.model.ProductDTO;

@Component

public class Converter {
	//convert from DTO to Entity - convert from DTO to entity and return entity object
	
	public Product convertToProductEntity(ProductDTO productDTO)
	{
		Product product = new Product();
		if(productDTO!=null)
		{
			BeanUtils.copyProperties(productDTO, product);
		}
		return product;
	}
	//convert from DTO to Entity-convert from entity to DTO and return DTO object
	public ProductDTO convertToProductDTO(Product product)
	{
		ProductDTO productDTO = new ProductDTO();
		if(product!=null)
		{
			BeanUtils.copyProperties(product, productDTO);
		}
		return productDTO;
	}

}
